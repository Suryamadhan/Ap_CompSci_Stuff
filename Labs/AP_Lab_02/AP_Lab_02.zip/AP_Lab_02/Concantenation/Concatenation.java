public class Concatenation
{
	public static void main(String[]args)
	{
		String name, address, city, zipCode;
		name = "Surya Madhan";
		address = "998877 Random Road";
		city = "San Diego";
		zipCode = "92130";
		System.out.println(name);
		System.out.println(address);
		System.out.println(city + ", " + zipCode);
	}
}