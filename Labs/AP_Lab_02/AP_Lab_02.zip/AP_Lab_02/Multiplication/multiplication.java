public class multiplication
{
	public static void main(String[]args)
	{
		int numberOne, numberTwo, product;
		numberOne = 4;
		numberTwo = 7;
		
		product = numberOne * numberTwo;
		
		System.out.println("The product of " + numberOne + " and " + numberTwo + " equals " + product + ".");
	}
}